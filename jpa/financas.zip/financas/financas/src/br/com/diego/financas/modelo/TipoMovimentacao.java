package br.com.diego.financas.modelo;

public enum TipoMovimentacao {
	ENTRADA, SAIDA; 
}
